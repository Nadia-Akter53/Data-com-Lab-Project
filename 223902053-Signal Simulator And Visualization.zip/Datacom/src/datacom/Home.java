
package datacom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Home extends javax.swing.JFrame {

   
    public Home() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 255, 204));

        jButton1.setBackground(new java.awt.Color(255, 204, 255));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/button6.png"))); // NOI18N
        jButton1.setText("NRZ-L");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(255, 204, 204));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/button6.png"))); // NOI18N
        jButton2.setText("NRZ-I");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(153, 255, 153));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/button5.png"))); // NOI18N
        jButton3.setText("Manchester");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(204, 255, 204));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/button5.png"))); // NOI18N
        jButton4.setText("Diff-Man");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Text  : ");

        jButton5.setBackground(new java.awt.Color(153, 255, 255));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/button4.png"))); // NOI18N
        jButton5.setText("Stuffing ");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(102, 255, 102));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/back22.png"))); // NOI18N
        jButton6.setText("Back");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/hhh3.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jButton6)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jButton1)
                            .addGap(18, 18, 18)
                            .addComponent(jButton2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jButton3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jButton4)
                            .addGap(18, 18, 18)
                            .addComponent(jButton5))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton3)
                    .addComponent(jButton2)
                    .addComponent(jButton1)
                    .addComponent(jButton5))
                .addGap(26, 26, 26)
                .addComponent(jButton6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed



        // Manchaster differential 
        
         String text = jTextField1.getText().trim();
        if (!text.isEmpty()) {
            String algo = "Rules:\n"
            + "1. Always transition at the start of a bit\n"
            + "2. For '0': Additional transition in middle\n"
            + "3. For '1': No additional transition";
            String binaryText = textToBinary(text);
            String encoded = encodeDifferentialManchester(binaryText);
            String name = "Differential Manchester Encoding Waveform";
            new Display(binaryText, encoded, name, algo).setVisible(true);
        } else {
            showError("Please enter some text!");
        }
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed


//----------------------
String text = jTextField1.getText().trim();
        if (!text.isEmpty()) {
           String binaryText = textToBinary(text);
        //   String nrzlEncoded = binaryText.toString();
          // String nrzlEncoded = "110011";
            String name = "NRZ-L Encoding Waveform";
            String algo = "1 = High voltage (0V)\n 0 = Low voltage";
            // Pass both to DisplayFrame
            new Display(binaryText, binaryText, name, algo).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(Home.this, 
                    "Please enter some text!", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
        }
    






        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

// NRZ-I

 String text = jTextField1.getText().trim();
        if (!text.isEmpty()) {
            String binaryText = textToBinary(text);
            String encoded = encodeNRZI(binaryText);
            String name = "NRZ-I Encoding Waveform";
            String algo = "1 = Transition (change voltage level)\n0 = No transition (maintain previous level)";
            new Display(binaryText, encoded, name,algo).setVisible(true);
        } else {
            showError("Please enter some text!");
        }

  
   
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed



        // Manchaster 
        
        String text = jTextField1.getText().trim();
        if (!text.isEmpty()) {
            String binaryText = textToBinary(text);
            String encoded = encodeManchester(binaryText);
            String name = "Manchester Encoding Waveform";
            String algo = "1 = High-to-low transition (10)\n0 = Low-to-high transition (01)";
            new Display(binaryText, encoded, name,algo).setVisible(true);
        } else {
            showError("Please enter some text!");
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // Button for Bit stuffing only 
        String text = jTextField1.getText().trim();
    if (!text.isEmpty()) {
     //   String binaryText = textToBinary(text);
     String binaryText= text;
        String stuffedData = bitStuffing(binaryText);
        String name = "Bit Stuffing";
         String algo = "Rules:\n"
            + "1. After every 5 consecutive '1's, insert a '0'\n"
            + "2. This prevents flag pattern (01111110) in data\n"
            + "3. Receiver removes the stuffed '0's";
        new Display(binaryText, stuffedData, name, algo).setVisible(true);
    } else {
        showError("Please enter some text!");
    }
}                                        

// Bit stuffing method
private String bitStuffing(String binary) {
    StringBuilder stuffed = new StringBuilder();
    int consecutiveOnes = 0;
    
    // Define the flag pattern (typically "01111110" for HDLC)
    final String FLAG = "01111110";
    final int MAX_CONSECUTIVE_ONES = 5; // After 5 consecutive 1s, we stuff a 0
    
    for (int i = 0; i < binary.length(); i++) {
        char currentBit = binary.charAt(i);
        stuffed.append(currentBit);
        
        if (currentBit == '1') {
            consecutiveOnes++;
            if (consecutiveOnes == MAX_CONSECUTIVE_ONES) {
                stuffed.append('0'); // Stuff a 0 after 5 consecutive 1s
                consecutiveOnes = 0; // Reset counter
            }
        } else {
            consecutiveOnes = 0; // Reset counter when a 0 is encountered
        }
    }
    
    // Add flags at beginning and end (optional, depending on your requirements)
    // stuffed.insert(0, FLAG).append(FLAG);
    
    return stuffed.toString();
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
 new admin().setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    
    // helping method 
    
      private String textToBinary(String text) {
        StringBuilder binaryText = new StringBuilder();
        for (char c : text.toCharArray()) {
            binaryText.append(String.format("%8s", Integer.toBinaryString(c)).replace(' ', '0'));
        }
        return binaryText.toString();
    }

    private String encodeNRZI(String binary) {
        StringBuilder encoded = new StringBuilder();
        boolean currentLevel = true; // Start with high level

        for (char bit : binary.toCharArray()) {
            if (bit == '1') {
                currentLevel = !currentLevel; // Toggle on '1'
            }
            encoded.append(currentLevel ? "1" : "0");
        }
        return encoded.toString();
    }
    
     // Standard Manchester Encoding (separate method)
    private String encodeManchester(String binary) {
        StringBuilder encoded = new StringBuilder();
        for (char bit : binary.toCharArray()) {
            // Manchester: 1 = high-to-low (10), 0 = low-to-high (01)
            encoded.append(bit == '1' ? "10" : "01");
        }
        return encoded.toString();
    }

    // Differential Manchester Encoding (separate method)
    private String encodeDifferentialManchester(String binary) {
        StringBuilder encoded = new StringBuilder();
        boolean currentLevel = true; // Start with high level
        
        for (char bit : binary.toCharArray()) {
            // Always transition at start of bit
            encoded.append(currentLevel ? "01" : "10");
            
            // For '0', add additional transition in middle
            if (bit == '0') {
                encoded.append(currentLevel ? "10" : "01");
                currentLevel = !currentLevel; // Toggle for next bit
            }
        }
        return encoded.toString();
    }
    
    
    
    
    
    

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    
    
   
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
