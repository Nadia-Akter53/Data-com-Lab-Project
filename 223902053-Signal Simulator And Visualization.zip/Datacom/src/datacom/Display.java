
package datacom;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;
import javax.swing.Timer;


public class Display extends javax.swing.JFrame {
  private String originalBits;
    private String encodedBits;
    private DrawPanel drawPanel;
    private Timer animationTimer;
    private int currentBitIndex = 0;
    private String name;
     private String algo;
    
    public Display(String originalBits, String encodedBits, String name, String algo) {
        this.originalBits = originalBits;
        this.encodedBits = encodedBits;
        this.name = name;
        this.algo = algo;

        initComponents();
        
        // Initialize and configure the drawing panel
        drawPanel = new DrawPanel();
        drawPanel.setBackground(Color.WHITE);
        drawPanel.setPreferredSize(new Dimension(600, 200));
        
        // Add the drawing panel to jPanel1
        jPanel1.setLayout(new BorderLayout());
        jPanel1.add(drawPanel, BorderLayout.CENTER);
        
        // Display the bits in text fields
        jTextField1.setText(originalBits);
        jTextField2.setText(encodedBits);
        jLabel1.setText(name);
         //jTextField3.setText(algo);
         
         jTextField3.setText(algo);
    jTextField3.setEditable(false); // Make it read-only
    jTextField3.setBackground(jPanel1.getBackground()); 
        
        // Start animation
        startAnimation();
    }
    
    private void startAnimation() {
        currentBitIndex = 0;
        if (animationTimer != null && animationTimer.isRunning()) {
            animationTimer.stop();
        }
        
        animationTimer = new Timer(1000, e -> {
            if (currentBitIndex <= encodedBits.length()) {
                drawPanel.setCurrentBitIndex(currentBitIndex);
                drawPanel.setBinary(encodedBits);
                currentBitIndex++;
            } else {
                animationTimer.stop();
                // Optionally restart animation or enable controls here
            }
        });
        animationTimer.start();
    }
    
    class DrawPanel extends JPanel {
        private String binary = "";
        private int currentBit = -1;

        public void setBinary(String binary) {
            this.binary = binary;
            repaint();
        }

        public void setCurrentBitIndex(int index) {
            this.currentBit = index;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            
            if (binary == null || binary.isEmpty()) return;

            int width = getWidth();
            int height = getHeight();
            int x = 30;
            int yHigh = height/2 - 40;
            int yLow = height/2 + 40;
            int yMid = height/2;
            
            // Calculate bit width to fit all bits in panel
            int bitWidth = Math.max(30, (width - 60) / binary.length());
            
            // Draw grid lines
            g.setColor(Color.LIGHT_GRAY);
            for (int i = 0; i <= binary.length(); i++) {
                g.drawLine(x + i*bitWidth, 20, x + i*bitWidth, height-20);
            }
            
            // Draw center axis line
            g.setColor(Color.BLACK);
            g.drawLine(30, yMid, width-30, yMid);
            
            // Draw waveform
            int prevY = yMid;
            g.setColor(new Color(0, 100, 200)); // Blue color for waveform
            
            for (int i = 0; i < binary.length(); i++) {
                char bit = binary.charAt(i);
                int y = (bit == '1') ? yHigh : yLow;
                
                // Highlight current bit being transmitted
                if (i == currentBit) {
                    g.setColor(Color.RED);
                    g.fillOval(x + (bitWidth/2) - 5, y - 5, 10, 10);
                    g.setColor(new Color(0, 100, 200));
                }
                
                // Draw vertical transition line if level changes
                if (i > 0 && binary.charAt(i-1) != bit) {
                    g.drawLine(x, prevY, x, y);
                }
                
                // Draw horizontal line for current bit
                g.drawLine(x, y, x + bitWidth, y);
                
                // Draw bit label below
                g.setColor(Color.BLACK);
                g.drawString(String.valueOf(bit), x + (bitWidth/2) - 3, yMid + 60);
                
                // Draw bit index above
                if (i % 2 == 0 || binary.length() < 15) {
                    g.drawString(String.valueOf(i), x + (bitWidth/2) - 3, 15);
                }
                
                prevY = y;
                x += bitWidth;
            }
            
            // Draw transmission direction arrow if animation is running
            if (currentBit >= 0 && currentBit < binary.length()) {
                g.setColor(Color.RED);
                int arrowX = 30 + currentBit * bitWidth + bitWidth/2;
                g.drawLine(arrowX, height-15, arrowX, height-25);
                g.drawLine(arrowX, height-25, arrowX-5, height-20);
                g.drawLine(arrowX, height-25, arrowX+5, height-20);
            }
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jTextField3 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 255, 255));

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 145, Short.MAX_VALUE)
        );

        jLabel1.setText("jLabel1");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Original bit : ");

        jTextField1.setBackground(new java.awt.Color(255, 255, 204));
        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Encoded bit : ");

        jTextField2.setBackground(new java.awt.Color(255, 255, 204));
        jTextField2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jButton1.setBackground(new java.awt.Color(51, 204, 255));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/back22.png"))); // NOI18N
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextField3.setBackground(new java.awt.Color(204, 255, 204));
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(207, 207, 207))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton1)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(6, 6, 6)))
                .addContainerGap(78, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel1)
                .addGap(26, 26, 26)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(36, 36, 36))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

this.dispose(); 
// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        
        
        
    }//GEN-LAST:event_jTextField3ActionPerformed

   
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Display("01001000", "01001000","Name", " ").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
